//
// main.cpp
// Created on 21/10/2018
//
#include "multimedia.h"
#include "video.h"
#include "photo.h"
#include <iostream>
#include <array>

#include "test.h"

using namespace std;

int main(int argc, const char* argv[])
{
    runTest_step_7();
    runTest_step_7_copy();
    return 0;
}
